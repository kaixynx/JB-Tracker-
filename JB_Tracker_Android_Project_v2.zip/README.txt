JB TRACKER ANDROID PROJECT

Isi:
- app/src/main/assets/index.html : aplikasi JB Tracker (offline-first, data lokal)
- MainActivity.kt : pembungkus Android WebView
- Google Sheets URL /exec sudah diisikan dari percakapan.

STATUS:
Ini adalah PROJECT SUMBER Android, belum berupa APK yang terkompilasi.
Lingkungan pembuatan file ini tidak menyediakan Android SDK/Gradle, jadi APK biner tidak bisa dibangun di sini.

CARA BUILD APK (sekali setup):
1. Instal Android Studio di komputer.
2. Buka folder JB_Tracker_Android_Project sebagai project.
3. Tunggu Gradle Sync selesai dan instal Android SDK 35 bila diminta.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

CATATAN DATA:
- Transaksi, produk, dan utang/piutang tersimpan di localStorage WebView pada perangkat.
- Backup JSON secara berkala dari menu Laporan/Pengaturan.
- Sinkronisasi memakai URL Apps Script yang disediakan. Format API POST yang dipakai:
  {"action":"upsert","type":"transaction"|"product","data":{...}}
- Aplikasi memakai mode no-cors untuk mengirim ke Apps Script, sehingga tampilan tidak bisa membaca respons sukses/gagal secara pasti. Periksa tab Transaksi/Produk di Google Sheets setelah sync.
- Data utang/piutang dan data transaksi pengeluaran ikut tersimpan lokal; implementasi sync saat ini mengirim transaksi dan produk.
- Jangan hapus data aplikasi sebelum membuat backup.

BUILD ONLINE VIA HP (GitHub Actions):
1. Buat repository GitHub baru bernama JB-Tracker dan set sebagai Public atau Private.
2. Upload seluruh isi folder project ini ke repository (termasuk folder tersembunyi .github/workflows).
3. Buka tab Actions pada repository. Jika diminta, aktifkan Actions.
4. Pilih workflow "Build JB Tracker APK", lalu tekan Run workflow.
5. Tunggu job selesai dengan status hijau. Buka hasil run dan unduh artifact bernama JB-Tracker-APK.
6. Ekstrak artifact ZIP untuk mendapatkan app-debug.apk, lalu pasang di Android.
Catatan: Workflow menggunakan GitHub-hosted runner. APK debug cocok untuk uji coba pribadi; untuk distribusi permanen sebaiknya buat signing key dan release build.
